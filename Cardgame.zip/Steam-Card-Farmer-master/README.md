# Steam Card Farmer

## A work-in-progress [Electron](http://electron.atom.io) app

*Looking for the old CLI version? It's still available on
[GitHub](https://github.com/DoctorMcKay/Steam-Card-Farmer/tree/old-cli) and
[npm](https://www.npmjs.com/package/steam-card-farmer).

## Usage

### Run / Test app
`npm test`

### Build app
`npm start`

## License

Released under [the GPLv3 license](https://opensource.org/licenses/GPL-3.0).
